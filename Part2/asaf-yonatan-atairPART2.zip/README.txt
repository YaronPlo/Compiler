

*** IMPORTANT ***

In order to run the project, right click on the "compile" file and click on properties.
Choose "Allow executing file as program" under Premissions tab. 

Now just go to terminal (in the same folder with "compile" file) and run the following command
    ./compile

In order to test the project with some text files, run the following command
    ./out<text_file_name        #if the text file in the same folder
    or
    ./out<path/text_file_name   #if the text file not in the same folder

If the text file is right in syntax and semantic terms, the message "OK" will be shown to you.
Otherwise, the relevant error message will be shown to you.

*****************

In the folder test, there are 2 folders containing run examples, working and failing.
In each of those folders, there are 18 examples.
